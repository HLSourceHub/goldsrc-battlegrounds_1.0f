/*
    Copyright 2001 to 2004. The Battle Grounds Team and Contributors

    This file is part of the Battle Grounds Modification for Half-Life.

    The Battle Grounds Modification for Half-Life is free software;
    you can redistribute it and/or modify it under the terms of the
    GNU Lesser General Public License as published by the Free
    Software Foundation; either version 2.1 of the License, or
    (at your option) any later version.

    The Battle Grounds Modification for Half-Life is distributed in
    the hope that it will be useful, but WITHOUT ANY WARRANTY; without
    even the implied warranty of MERCHANTABILITY or FITNESS FOR A
    PARTICULAR PURPOSE.  See the GNU Lesser General Public License
    for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with The Battle Grounds Modification for Half-Life;
    if not, write to the Free Software Foundation, Inc., 59 Temple Place,
    Suite 330, Boston, MA  02111-1307  USA

    You must obey the GNU Lesser General Public License in all respects for
    all of the code used other than code distributed with the Half-Life
    SDK developed by Valve.  If you modify this file, you may extend this
    exception to your version of the file, but you are not obligated to do so.
    If you do not wish to do so, delete this exception statement from your
    version.
*/


#ifndef VGUI_BITMAP_H
#define VGUI_BITMAP_H

#include<VGUI.h>
#include<VGUI_Image.h>

namespace vgui
{

class Panel;

class VGUIAPI Bitmap : public Image
{
private:
	int         _id;
	bool        _uploaded;
public:
	Bitmap();
protected:
	virtual void setSize(int wide,int tall);
	virtual void setRGBA(int x,int y,uchar r,uchar g,uchar b,uchar a);
public:
	virtual void paint(Panel* panel);
protected:
	uchar* _rgba;
};

}

#endif